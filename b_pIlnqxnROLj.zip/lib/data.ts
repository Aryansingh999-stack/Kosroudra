export interface Kitchen {
  id: string
  name: string
  image: string
  rating: number
  deliveryTime: string
  tags: string[]
  cuisine: string
}

export interface FoodItem {
  id: string
  name: string
  description: string
  image: string
  price: number
  kitchenName: string
  kitchenId: string
  category: string
  isVeg: boolean
  isBestseller?: boolean
}

export interface Category {
  id: string
  name: string
  icon: string
  image: string
}

export const categories: Category[] = [
  { id: '1', name: 'Biryani', icon: '🍚', image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=300&h=200&fit=crop' },
  { id: '2', name: 'Pizza', icon: '🍕', image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=300&h=200&fit=crop' },
  { id: '3', name: 'Burgers', icon: '🍔', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&h=200&fit=crop' },
  { id: '4', name: 'Chinese', icon: '🥡', image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=300&h=200&fit=crop' },
  { id: '5', name: 'Healthy', icon: '🥗', image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=300&h=200&fit=crop' },
  { id: '6', name: 'Desserts', icon: '🍰', image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=300&h=200&fit=crop' },
  { id: '7', name: 'South Indian', icon: '🥘', image: 'https://images.unsplash.com/photo-1630383249896-424e482df921?w=300&h=200&fit=crop' },
  { id: '8', name: 'Rolls', icon: '🌯', image: 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=300&h=200&fit=crop' },
]

export const kitchens: Kitchen[] = [
  {
    id: '1',
    name: 'Spice Symphony',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=300&fit=crop',
    rating: 4.5,
    deliveryTime: '25-30 min',
    tags: ['Pure Veg', 'Bestseller'],
    cuisine: 'North Indian',
  },
  {
    id: '2',
    name: 'Pizza Paradise',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400&h=300&fit=crop',
    rating: 4.3,
    deliveryTime: '30-35 min',
    tags: ['Fast Delivery'],
    cuisine: 'Italian',
  },
  {
    id: '3',
    name: 'Wok & Roll',
    image: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?w=400&h=300&fit=crop',
    rating: 4.7,
    deliveryTime: '20-25 min',
    tags: ['Bestseller', 'Fast Delivery'],
    cuisine: 'Chinese',
  },
  {
    id: '4',
    name: 'Green Bowl',
    image: 'https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?w=400&h=300&fit=crop',
    rating: 4.6,
    deliveryTime: '25-30 min',
    tags: ['Pure Veg', 'Healthy'],
    cuisine: 'Healthy',
  },
  {
    id: '5',
    name: 'Biryani Blues',
    image: 'https://images.unsplash.com/photo-1565299507177-b0ac66763828?w=400&h=300&fit=crop',
    rating: 4.8,
    deliveryTime: '35-40 min',
    tags: ['Bestseller'],
    cuisine: 'Biryani',
  },
  {
    id: '6',
    name: 'Burger Barn',
    image: 'https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=400&h=300&fit=crop',
    rating: 4.4,
    deliveryTime: '20-25 min',
    tags: ['Fast Delivery'],
    cuisine: 'American',
  },
]

export const foodItems: FoodItem[] = [
  {
    id: '1',
    name: 'Hyderabadi Chicken Biryani',
    description: 'Aromatic basmati rice layered with tender chicken and authentic spices',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400&h=300&fit=crop',
    price: 299,
    kitchenName: 'Biryani Blues',
    kitchenId: '5',
    category: 'Biryani',
    isVeg: false,
    isBestseller: true,
  },
  {
    id: '2',
    name: 'Margherita Pizza',
    description: 'Classic pizza with fresh mozzarella, tomatoes, and basil',
    image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=400&h=300&fit=crop',
    price: 249,
    kitchenName: 'Pizza Paradise',
    kitchenId: '2',
    category: 'Pizza',
    isVeg: true,
  },
  {
    id: '3',
    name: 'Schezwan Fried Rice',
    description: 'Spicy fried rice with vegetables and schezwan sauce',
    image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&h=300&fit=crop',
    price: 179,
    kitchenName: 'Wok & Roll',
    kitchenId: '3',
    category: 'Chinese',
    isVeg: true,
    isBestseller: true,
  },
  {
    id: '4',
    name: 'Classic Cheese Burger',
    description: 'Juicy beef patty with melted cheese, lettuce, and special sauce',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop',
    price: 199,
    kitchenName: 'Burger Barn',
    kitchenId: '6',
    category: 'Burgers',
    isVeg: false,
  },
  {
    id: '5',
    name: 'Quinoa Buddha Bowl',
    description: 'Nutritious bowl with quinoa, roasted veggies, and tahini dressing',
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop',
    price: 279,
    kitchenName: 'Green Bowl',
    kitchenId: '4',
    category: 'Healthy',
    isVeg: true,
  },
  {
    id: '6',
    name: 'Paneer Tikka',
    description: 'Grilled cottage cheese marinated in spiced yogurt',
    image: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=400&h=300&fit=crop',
    price: 229,
    kitchenName: 'Spice Symphony',
    kitchenId: '1',
    category: 'North Indian',
    isVeg: true,
    isBestseller: true,
  },
  {
    id: '7',
    name: 'Chocolate Lava Cake',
    description: 'Warm chocolate cake with molten center, served with ice cream',
    image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=400&h=300&fit=crop',
    price: 149,
    kitchenName: 'Sweet Treats',
    kitchenId: '7',
    category: 'Desserts',
    isVeg: true,
  },
  {
    id: '8',
    name: 'Chicken Momos',
    description: 'Steamed dumplings filled with spiced chicken, served with chutney',
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=400&h=300&fit=crop',
    price: 159,
    kitchenName: 'Wok & Roll',
    kitchenId: '3',
    category: 'Chinese',
    isVeg: false,
  },
  {
    id: '9',
    name: 'Pepperoni Pizza',
    description: 'Loaded with spicy pepperoni and melted mozzarella cheese',
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400&h=300&fit=crop',
    price: 329,
    kitchenName: 'Pizza Paradise',
    kitchenId: '2',
    category: 'Pizza',
    isVeg: false,
    isBestseller: true,
  },
  {
    id: '10',
    name: 'Veg Biryani',
    description: 'Fragrant basmati rice cooked with mixed vegetables and spices',
    image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=400&h=300&fit=crop',
    price: 219,
    kitchenName: 'Biryani Blues',
    kitchenId: '5',
    category: 'Biryani',
    isVeg: true,
  },
  {
    id: '11',
    name: 'BBQ Chicken Burger',
    description: 'Grilled chicken with BBQ sauce, caramelized onions, and coleslaw',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?w=400&h=300&fit=crop',
    price: 249,
    kitchenName: 'Burger Barn',
    kitchenId: '6',
    category: 'Burgers',
    isVeg: false,
  },
  {
    id: '12',
    name: 'Masala Dosa',
    description: 'Crispy rice crepe filled with spiced potato masala',
    image: 'https://images.unsplash.com/photo-1630383249896-424e482df921?w=400&h=300&fit=crop',
    price: 129,
    kitchenName: 'Spice Symphony',
    kitchenId: '1',
    category: 'South Indian',
    isVeg: true,
  },
]

export const offers = [
  {
    id: '1',
    title: '50% OFF',
    description: 'On your first order',
    code: 'WELCOME50',
    bgColor: 'from-primary to-accent',
  },
  {
    id: '2',
    title: 'Free Delivery',
    description: 'On orders above ₹299',
    code: 'FREEDEL',
    bgColor: 'from-accent to-primary',
  },
  {
    id: '3',
    title: '₹100 OFF',
    description: 'On orders above ₹499',
    code: 'SAVE100',
    bgColor: 'from-primary to-accent',
  },
]
