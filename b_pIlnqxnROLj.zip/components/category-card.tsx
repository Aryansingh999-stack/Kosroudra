"use client"

import Link from 'next/link'
import type { Category } from '@/lib/data'

interface CategoryCardProps {
  category: Category
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link
      href={`/menu?category=${encodeURIComponent(category.name)}`}
      className="group flex flex-col items-center gap-3"
    >
      <div className="relative w-24 h-24 md:w-28 md:h-28 rounded-full overflow-hidden shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-105 ring-4 ring-transparent group-hover:ring-primary/20">
        <img
          src={category.image}
          alt={category.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 to-transparent" />
      </div>
      <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
        {category.name}
      </span>
    </Link>
  )
}
