"use client"

import { Plus, Leaf } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useCartStore } from '@/lib/cart-store'
import type { FoodItem } from '@/lib/data'

interface FoodCardProps {
  item: FoodItem
}

export function FoodCard({ item }: FoodCardProps) {
  const addItem = useCartStore((state) => state.addItem)
  const openCart = useCartStore((state) => state.openCart)

  const handleAddToCart = () => {
    addItem(item)
    openCart()
  }

  return (
    <div className="group bg-card rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-border hover:border-primary/20">
      <div className="relative h-44 overflow-hidden">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 via-transparent to-transparent" />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-2">
          {item.isVeg && (
            <Badge variant="secondary" className="bg-green-500/90 text-white border-0">
              <Leaf className="w-3 h-3 mr-1" />
              Veg
            </Badge>
          )}
          {item.isBestseller && (
            <Badge variant="secondary" className="bg-primary/90 text-primary-foreground border-0">
              Bestseller
            </Badge>
          )}
        </div>

        {/* Add Button */}
        <div className="absolute bottom-3 right-3">
          <Button
            size="sm"
            onClick={handleAddToCart}
            className="shadow-lg gap-1"
          >
            <Plus className="w-4 h-4" />
            Add
          </Button>
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-base font-semibold text-foreground mb-1 line-clamp-1">
          {item.name}
        </h3>
        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
          {item.description}
        </p>
        <div className="flex items-center justify-between">
          <p className="text-lg font-bold text-foreground">
            ₹{item.price}
          </p>
          <p className="text-xs text-muted-foreground">
            {item.kitchenName}
          </p>
        </div>
      </div>
    </div>
  )
}
