"use client"

import { Star, Clock } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import Link from 'next/link'
import type { Kitchen } from '@/lib/data'

interface KitchenCardProps {
  kitchen: Kitchen
}

export function KitchenCard({ kitchen }: KitchenCardProps) {
  return (
    <Link
      href={`/menu?kitchen=${encodeURIComponent(kitchen.id)}`}
      className="group block bg-card rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-border hover:border-primary/20"
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={kitchen.image}
          alt={kitchen.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-transparent" />
        
        {/* Tags */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-2">
          {kitchen.tags.map((tag) => (
            <Badge
              key={tag}
              variant="secondary"
              className="bg-card/90 backdrop-blur-sm text-xs font-medium"
            >
              {tag}
            </Badge>
          ))}
        </div>

        {/* Rating */}
        <div className="absolute bottom-3 left-3 flex items-center gap-1 bg-card/90 backdrop-blur-sm px-2 py-1 rounded-lg">
          <Star className="w-4 h-4 text-accent fill-accent" />
          <span className="text-sm font-semibold text-foreground">{kitchen.rating}</span>
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors mb-1">
          {kitchen.name}
        </h3>
        <p className="text-sm text-muted-foreground mb-3">{kitchen.cuisine}</p>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span>{kitchen.deliveryTime}</span>
        </div>
      </div>
    </Link>
  )
}
