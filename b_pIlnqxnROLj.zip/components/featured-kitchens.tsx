"use client"

import { kitchens } from '@/lib/data'
import { KitchenCard } from './kitchen-card'
import { Button } from '@/components/ui/button'
import { ArrowRight } from 'lucide-react'
import Link from 'next/link'

export function FeaturedKitchens() {
  return (
    <section className="py-12 md:py-16 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
              Featured Cloud Kitchens
            </h2>
            <p className="text-muted-foreground">
              Handpicked kitchens with the best ratings
            </p>
          </div>
          <Link href="/menu" className="hidden md:block">
            <Button variant="ghost" className="gap-2">
              View All
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {kitchens.map((kitchen) => (
            <KitchenCard key={kitchen.id} kitchen={kitchen} />
          ))}
        </div>

        <div className="mt-8 text-center md:hidden">
          <Link href="/menu">
            <Button variant="outline" className="gap-2">
              View All Kitchens
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
