"use client"

import { categories } from '@/lib/data'
import { CategoryCard } from './category-card'

export function CategoriesSection() {
  return (
    <section className="py-12 md:py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
            What are you craving?
          </h2>
          <p className="text-muted-foreground">
            Explore our wide variety of cuisines
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-6 md:gap-8">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>
    </section>
  )
}
