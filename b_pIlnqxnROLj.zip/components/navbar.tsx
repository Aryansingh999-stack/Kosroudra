"use client"

import { useState } from 'react'
import { Search, MapPin, ShoppingCart, Menu, X, ChefHat } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useCartStore } from '@/lib/cart-store'
import Link from 'next/link'

interface NavbarProps {
  onAuthClick: () => void
  onCartClick: () => void
}

export function Navbar({ onAuthClick, onCartClick }: NavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [location, setLocation] = useState('Select Location')
  const totalItems = useCartStore((state) => state.getTotalItems())

  return (
    <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-lg border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
              <ChefHat className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">CloudBite</span>
          </Link>

          {/* Location Selector - Desktop */}
          <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-secondary rounded-full cursor-pointer hover:bg-secondary/80 transition-colors">
            <MapPin className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-secondary-foreground">{location}</span>
          </div>

          {/* Search Bar - Desktop */}
          <div className="hidden lg:flex flex-1 max-w-md mx-6">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search food, cuisines, kitchens..."
                className="w-full pl-10 pr-4 py-2 bg-secondary border-0 rounded-full focus-visible:ring-2 focus-visible:ring-primary"
              />
            </div>
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-3">
            {/* Cart Button */}
            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={onCartClick}
            >
              <ShoppingCart className="w-5 h-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-primary-foreground text-xs font-bold rounded-full flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Button>

            {/* Auth Buttons - Desktop */}
            <div className="hidden md:flex items-center gap-2">
              <Button variant="ghost" onClick={onAuthClick}>
                Login
              </Button>
              <Button onClick={onAuthClick}>
                Sign Up
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            {/* Mobile Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search food, cuisines, kitchens..."
                className="w-full pl-10 pr-4 py-2 bg-secondary border-0 rounded-full"
              />
            </div>

            {/* Mobile Location */}
            <div className="flex items-center gap-2 px-4 py-3 bg-secondary rounded-xl mb-4">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-secondary-foreground">{location}</span>
            </div>

            {/* Mobile Auth Buttons */}
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={onAuthClick}>
                Login
              </Button>
              <Button className="flex-1" onClick={onAuthClick}>
                Sign Up
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
