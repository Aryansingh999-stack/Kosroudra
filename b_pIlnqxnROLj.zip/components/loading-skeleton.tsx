"use client"

import { cn } from '@/lib/utils'

export function FoodCardSkeleton() {
  return (
    <div className="bg-card rounded-2xl overflow-hidden shadow-md border border-border animate-pulse">
      <div className="h-44 bg-muted" />
      <div className="p-4 space-y-3">
        <div className="h-4 bg-muted rounded w-3/4" />
        <div className="h-3 bg-muted rounded w-full" />
        <div className="h-3 bg-muted rounded w-1/2" />
        <div className="flex justify-between items-center">
          <div className="h-5 bg-muted rounded w-16" />
          <div className="h-3 bg-muted rounded w-20" />
        </div>
      </div>
    </div>
  )
}

export function KitchenCardSkeleton() {
  return (
    <div className="bg-card rounded-2xl overflow-hidden shadow-md border border-border animate-pulse">
      <div className="h-48 bg-muted" />
      <div className="p-4 space-y-3">
        <div className="h-5 bg-muted rounded w-2/3" />
        <div className="h-4 bg-muted rounded w-1/3" />
        <div className="h-4 bg-muted rounded w-1/2" />
      </div>
    </div>
  )
}

export function CategorySkeleton() {
  return (
    <div className="flex flex-col items-center gap-3 animate-pulse">
      <div className="w-24 h-24 md:w-28 md:h-28 rounded-full bg-muted" />
      <div className="h-4 bg-muted rounded w-16" />
    </div>
  )
}

export function FilterSidebarSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="space-y-3">
        <div className="h-5 bg-muted rounded w-20" />
        <div className="space-y-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="w-4 h-4 bg-muted rounded" />
              <div className="h-4 bg-muted rounded w-24" />
            </div>
          ))}
        </div>
      </div>
      <div className="space-y-3">
        <div className="h-5 bg-muted rounded w-24" />
        <div className="h-8 bg-muted rounded" />
      </div>
    </div>
  )
}
