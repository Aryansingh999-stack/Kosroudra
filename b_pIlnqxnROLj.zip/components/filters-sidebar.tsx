"use client"

import { useState } from 'react'
import { X, Star, Filter } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { categories } from '@/lib/data'

interface FiltersSidebarProps {
  isOpen: boolean
  onClose: () => void
  filters: {
    cuisines: string[]
    priceRange: [number, number]
    rating: number
    vegOnly: boolean
    deliveryTime: string
  }
  onFilterChange: (filters: FiltersSidebarProps['filters']) => void
}

const deliveryTimeOptions = [
  { value: 'any', label: 'Any Time' },
  { value: '20', label: 'Under 20 min' },
  { value: '30', label: 'Under 30 min' },
  { value: '45', label: 'Under 45 min' },
]

export function FiltersSidebar({
  isOpen,
  onClose,
  filters,
  onFilterChange,
}: FiltersSidebarProps) {
  const [localFilters, setLocalFilters] = useState(filters)

  const handleCuisineChange = (cuisine: string, checked: boolean) => {
    const newCuisines = checked
      ? [...localFilters.cuisines, cuisine]
      : localFilters.cuisines.filter((c) => c !== cuisine)
    setLocalFilters({ ...localFilters, cuisines: newCuisines })
  }

  const handleApply = () => {
    onFilterChange(localFilters)
    onClose()
  }

  const handleReset = () => {
    const resetFilters = {
      cuisines: [],
      priceRange: [0, 500] as [number, number],
      rating: 0,
      vegOnly: false,
      deliveryTime: 'any',
    }
    setLocalFilters(resetFilters)
    onFilterChange(resetFilters)
  }

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-foreground/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed lg:sticky top-0 lg:top-20 left-0 h-full lg:h-auto w-80 lg:w-64
          bg-card lg:bg-transparent border-r lg:border-0 border-border
          p-6 overflow-y-auto z-50 lg:z-0
          transform transition-transform duration-300 lg:transform-none
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-foreground">Filters</h2>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={onClose}
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Cuisines */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-foreground mb-3">Cuisines</h3>
          <div className="space-y-2">
            {categories.map((category) => (
              <div key={category.id} className="flex items-center gap-2">
                <Checkbox
                  id={`cuisine-${category.id}`}
                  checked={localFilters.cuisines.includes(category.name)}
                  onCheckedChange={(checked) =>
                    handleCuisineChange(category.name, checked as boolean)
                  }
                />
                <Label
                  htmlFor={`cuisine-${category.id}`}
                  className="text-sm font-normal cursor-pointer"
                >
                  {category.name}
                </Label>
              </div>
            ))}
          </div>
        </div>

        {/* Price Range */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-foreground mb-3">
            Price Range
          </h3>
          <div className="px-1">
            <Slider
              value={localFilters.priceRange}
              onValueChange={(value) =>
                setLocalFilters({
                  ...localFilters,
                  priceRange: value as [number, number],
                })
              }
              max={500}
              step={50}
              className="mb-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>₹{localFilters.priceRange[0]}</span>
              <span>₹{localFilters.priceRange[1]}</span>
            </div>
          </div>
        </div>

        {/* Rating */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-foreground mb-3">
            Minimum Rating
          </h3>
          <div className="flex gap-2">
            {[0, 3, 3.5, 4, 4.5].map((rating) => (
              <button
                key={rating}
                onClick={() => setLocalFilters({ ...localFilters, rating })}
                className={`
                  flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-medium transition-colors
                  ${
                    localFilters.rating === rating
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                  }
                `}
              >
                {rating === 0 ? (
                  'Any'
                ) : (
                  <>
                    <Star className="w-3 h-3 fill-current" />
                    {rating}+
                  </>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Veg Only */}
        <div className="mb-6">
          <div className="flex items-center gap-2">
            <Checkbox
              id="veg-only"
              checked={localFilters.vegOnly}
              onCheckedChange={(checked) =>
                setLocalFilters({ ...localFilters, vegOnly: checked as boolean })
              }
            />
            <Label htmlFor="veg-only" className="text-sm font-normal cursor-pointer">
              Vegetarian Only
            </Label>
          </div>
        </div>

        {/* Delivery Time */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-foreground mb-3">
            Delivery Time
          </h3>
          <div className="space-y-2">
            {deliveryTimeOptions.map((option) => (
              <div key={option.value} className="flex items-center gap-2">
                <input
                  type="radio"
                  id={`delivery-${option.value}`}
                  name="deliveryTime"
                  value={option.value}
                  checked={localFilters.deliveryTime === option.value}
                  onChange={() =>
                    setLocalFilters({ ...localFilters, deliveryTime: option.value })
                  }
                  className="w-4 h-4 text-primary border-border focus:ring-primary"
                />
                <Label
                  htmlFor={`delivery-${option.value}`}
                  className="text-sm font-normal cursor-pointer"
                >
                  {option.label}
                </Label>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-4 border-t border-border">
          <Button variant="outline" className="flex-1" onClick={handleReset}>
            Reset
          </Button>
          <Button className="flex-1" onClick={handleApply}>
            Apply
          </Button>
        </div>
      </aside>
    </>
  )
}
