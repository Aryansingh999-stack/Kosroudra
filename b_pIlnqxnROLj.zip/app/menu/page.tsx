"use client"

import { useState, useMemo, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { FoodCard } from '@/components/food-card'
import { FiltersSidebar } from '@/components/filters-sidebar'
import { CartPanel } from '@/components/cart-panel'
import { AuthModal } from '@/components/auth-modal'
import { Footer } from '@/components/footer'
import { FoodCardSkeleton } from '@/components/loading-skeleton'
import { useCartStore } from '@/lib/cart-store'
import { foodItems } from '@/lib/data'
import { Button } from '@/components/ui/button'
import { Filter, SlidersHorizontal, ChevronDown, Search, X } from 'lucide-react'
import { Input } from '@/components/ui/input'

const sortOptions = [
  { value: 'popularity', label: 'Popularity' },
  { value: 'rating', label: 'Rating' },
  { value: 'price-low', label: 'Price: Low to High' },
  { value: 'price-high', label: 'Price: High to Low' },
]

function MenuPageContent() {
  const searchParams = useSearchParams()
  const initialCategory = searchParams.get('category') || ''
  
  const [isAuthOpen, setIsAuthOpen] = useState(false)
  const [isFiltersOpen, setIsFiltersOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [sortBy, setSortBy] = useState('popularity')
  const [isSortOpen, setIsSortOpen] = useState(false)
  const { isOpen: isCartOpen, closeCart, openCart } = useCartStore()

  const [filters, setFilters] = useState({
    cuisines: initialCategory ? [initialCategory] : [],
    priceRange: [0, 500] as [number, number],
    rating: 0,
    vegOnly: false,
    deliveryTime: 'any',
  })

  const filteredItems = useMemo(() => {
    let items = [...foodItems]

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      items = items.filter(
        (item) =>
          item.name.toLowerCase().includes(query) ||
          item.kitchenName.toLowerCase().includes(query) ||
          item.category.toLowerCase().includes(query)
      )
    }

    // Cuisine filter
    if (filters.cuisines.length > 0) {
      items = items.filter((item) => filters.cuisines.includes(item.category))
    }

    // Price filter
    items = items.filter(
      (item) =>
        item.price >= filters.priceRange[0] && item.price <= filters.priceRange[1]
    )

    // Veg filter
    if (filters.vegOnly) {
      items = items.filter((item) => item.isVeg)
    }

    // Sort
    switch (sortBy) {
      case 'price-low':
        items.sort((a, b) => a.price - b.price)
        break
      case 'price-high':
        items.sort((a, b) => b.price - a.price)
        break
      case 'rating':
        items.sort((a, b) => (b.isBestseller ? 1 : 0) - (a.isBestseller ? 1 : 0))
        break
      default:
        // Popularity - bestsellers first
        items.sort((a, b) => (b.isBestseller ? 1 : 0) - (a.isBestseller ? 1 : 0))
    }

    return items
  }, [searchQuery, filters, sortBy])

  const activeFiltersCount = useMemo(() => {
    let count = 0
    if (filters.cuisines.length > 0) count++
    if (filters.priceRange[0] > 0 || filters.priceRange[1] < 500) count++
    if (filters.rating > 0) count++
    if (filters.vegOnly) count++
    if (filters.deliveryTime !== 'any') count++
    return count
  }, [filters])

  return (
    <div className="min-h-screen bg-background">
      <Navbar onAuthClick={() => setIsAuthOpen(true)} onCartClick={openCart} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
            Order Food Online
          </h1>
          <p className="text-muted-foreground">
            {filteredItems.length} items found
          </p>
        </div>

        {/* Search and Sort Bar */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search for food, kitchen..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-10"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Filter Button - Mobile */}
          <Button
            variant="outline"
            className="lg:hidden gap-2"
            onClick={() => setIsFiltersOpen(true)}
          >
            <Filter className="w-4 h-4" />
            Filters
            {activeFiltersCount > 0 && (
              <span className="w-5 h-5 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center">
                {activeFiltersCount}
              </span>
            )}
          </Button>

          {/* Sort Dropdown */}
          <div className="relative">
            <Button
              variant="outline"
              className="gap-2 min-w-[180px] justify-between"
              onClick={() => setIsSortOpen(!isSortOpen)}
            >
              <span className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4" />
                {sortOptions.find((o) => o.value === sortBy)?.label}
              </span>
              <ChevronDown className="w-4 h-4" />
            </Button>
            {isSortOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setIsSortOpen(false)}
                />
                <div className="absolute right-0 top-full mt-2 w-48 bg-card border border-border rounded-xl shadow-lg z-50 py-1">
                  {sortOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => {
                        setSortBy(option.value)
                        setIsSortOpen(false)
                      }}
                      className={`w-full text-left px-4 py-2 text-sm hover:bg-secondary transition-colors ${
                        sortBy === option.value
                          ? 'text-primary font-medium'
                          : 'text-foreground'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Active Filters Tags */}
        {(filters.cuisines.length > 0 || filters.vegOnly) && (
          <div className="flex flex-wrap gap-2 mb-6">
            {filters.cuisines.map((cuisine) => (
              <span
                key={cuisine}
                className="inline-flex items-center gap-1 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm"
              >
                {cuisine}
                <button
                  onClick={() =>
                    setFilters({
                      ...filters,
                      cuisines: filters.cuisines.filter((c) => c !== cuisine),
                    })
                  }
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
            {filters.vegOnly && (
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                Veg Only
                <button onClick={() => setFilters({ ...filters, vegOnly: false })}>
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
          </div>
        )}

        <div className="flex gap-6">
          {/* Filters Sidebar - Desktop */}
          <div className="hidden lg:block">
            <FiltersSidebar
              isOpen={true}
              onClose={() => {}}
              filters={filters}
              onFilterChange={setFilters}
            />
          </div>

          {/* Food Grid */}
          <div className="flex-1">
            {filteredItems.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredItems.map((item) => (
                  <FoodCard key={item.id} item={item} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="w-24 h-24 bg-secondary rounded-full flex items-center justify-center mb-4">
                  <Search className="w-12 h-12 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  No items found
                </h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your filters or search query
                </p>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSearchQuery('')
                    setFilters({
                      cuisines: [],
                      priceRange: [0, 500],
                      rating: 0,
                      vegOnly: false,
                      deliveryTime: 'any',
                    })
                  }}
                >
                  Clear All Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />

      {/* Mobile Filters Sidebar */}
      <FiltersSidebar
        isOpen={isFiltersOpen}
        onClose={() => setIsFiltersOpen(false)}
        filters={filters}
        onFilterChange={setFilters}
      />

      <CartPanel isOpen={isCartOpen} onClose={closeCart} />
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </div>
  )
}

export default function MenuPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    }>
      <MenuPageContent />
    </Suspense>
  )
}
