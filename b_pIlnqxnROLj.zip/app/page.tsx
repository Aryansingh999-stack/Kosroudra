"use client"

import { useState } from 'react'
import { Navbar } from '@/components/navbar'
import { Hero } from '@/components/hero'
import { CategoriesSection } from '@/components/categories-section'
import { FeaturedKitchens } from '@/components/featured-kitchens'
import { OffersBanner } from '@/components/offers-banner'
import { CartPanel } from '@/components/cart-panel'
import { AuthModal } from '@/components/auth-modal'
import { Footer } from '@/components/footer'
import { useCartStore } from '@/lib/cart-store'

export default function HomePage() {
  const [isAuthOpen, setIsAuthOpen] = useState(false)
  const { isOpen: isCartOpen, closeCart, openCart } = useCartStore()

  return (
    <div className="min-h-screen bg-background">
      <Navbar onAuthClick={() => setIsAuthOpen(true)} onCartClick={openCart} />
      
      <main>
        <Hero />
        <CategoriesSection />
        <FeaturedKitchens />
        <OffersBanner />
      </main>

      <Footer />

      <CartPanel isOpen={isCartOpen} onClose={closeCart} />
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </div>
  )
}
